﻿using System;

namespace Enum_Use
{
    class Program
    {
        public enum Months
        {
            January = 1,
            February ,
            March ,
            April ,
            May ,
            June ,
            July ,
            August ,
            September ,
            October ,
            November ,
            December
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number of Month or Multiple Months seperated by Comma: ");
            string[] input = Console.ReadLine().Split(',');
            for (int month = 0; month < input.Length; month++)
            {
                Months option = (Months)Convert.ToInt32(input[month]);
                Console.WriteLine(option);
            }
            Console.ReadLine();
        }
    }
}
