﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access_Modifiers
{
    class Name
    {
        public string Country = "India";
        protected string State = "Delhi";
        private static void Place(string name)
        {
            Console.WriteLine("Kellton Tech");
        }
    }
    class Program : Name
    {
        static void Main(string[] args)
        {
            Name Countryobj = new Name();
            Console.WriteLine(Countryobj.Country);
            Console.ReadLine();

            Program Stateobj = new Program();
            Console.WriteLine(Stateobj.State);
            Console.ReadLine();

            Place();
        }
    }

}
