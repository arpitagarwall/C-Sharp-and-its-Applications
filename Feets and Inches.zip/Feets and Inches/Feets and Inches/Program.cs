﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feets_and_Inches
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input Value Feet  : ");
            int feet = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input Value Inches  : ");
            int inches = Convert.ToInt32(Console.ReadLine());

            int feets = feet * 12;
            int Total = feets + inches;

            int Totalfeets = Total / 12;
            int Totalinches = Total % 12;

            Console.WriteLine("{0} Feet  : {1} Inches", Totalfeets, Totalinches);
            Console.ReadLine();
        }
    }
}
