﻿using System;


namespace Singleton
{
    public sealed class Singleton
    {
        private static Singleton instance = null;
         private static readonly object obj = new object();

        private Singleton()
        {
            Console.WriteLine("In Constructor");
            
        }

        public void Display1()
        {
            Console.WriteLine("Hello1");
        }

        public void Display2()
        {
            Console.WriteLine("Hello2");
        }

        public static Singleton GetObject()
        {
        
                if (instance == null)
                {
                    lock (obj)
                    {
                        if (instance == null)
                        {
                            instance = new Singleton();

                        }
                        return instance;
                    }
                }
                return instance;
            
        }

        public class NestedClass
        {
            public void DisplayNestedClass()
            {
                Singleton obj4 = new Singleton();
                obj4.Display1();
            }
        }
    }
}