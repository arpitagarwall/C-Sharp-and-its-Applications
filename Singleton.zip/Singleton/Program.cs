﻿using System;
using System.Threading.Tasks;
namespace Singleton
{
    internal class Program
    {
        private static void Method1()
        {
            Singleton obj1 = Singleton.GetObject();
            obj1.Display1();
        }
        private static void Method2()
        {
            Singleton obj2 = Singleton.GetObject();
            obj2.Display2();
        }

        //private static void Method3()
        //{
        //    Singleton.NestedClass obj = new Singleton.NestedClass();
        //    obj.DisplayNestedClass();
        //}

        

        static void Main(string[] args)
        {
            Parallel.Invoke(
                    () => Method1(),
                    () => Method2()
                 

                );


        }
    }
}

