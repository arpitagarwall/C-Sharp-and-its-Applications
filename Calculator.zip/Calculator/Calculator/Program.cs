﻿using System;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Enter the Choice for which you have to perform Mathematical Operation:\n");

                Console.Write("1-Addition(+).\n2-Subtraction(-).\n3-Multiplication(*).\n4-Division(/).\n5-Exit.");

                Console.Write("\nInput your choice : ");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.Write("Enter the First number: ");
                        int num1 = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the Second Number: ");
                        int num2 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("The Addition of First Number {0} and Second Number {1} is: {2}\n", num1, num2, num1 + num2);
                        Console.ReadLine();
                        break;

                    case 2:

                        Console.Write("Enter the First number: ");
                        int num3 = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the Second Number: ");
                        int num4 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("The Subtraction of First Number {0} and Second Number {1} is: {2}\n", num3, num4, num3 - num4);
                        Console.ReadLine();
                        break;

                    case 3:

                        Console.Write("Enter the First number: ");
                        int num5 = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the Second Number: ");
                        int num6 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("The Multipication of First Number {0} and Second Number {1} is: {2}\n", num5, num6, num5 * num6);
                        Console.ReadLine();
                        break;

                    case 4:

                        Console.Write("Enter the First number: ");
                        int num7 = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the Second Number: ");
                        int num8 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("The Division of First Number {0} and Second Number {1} is: {2}\n", num7, num8, num7 / num8);
                        Console.ReadLine();
                        break;

                    case 5:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid Input");
                        break;
                }
            }
        }
    }
}
