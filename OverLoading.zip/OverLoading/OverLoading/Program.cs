﻿using System;

namespace OverLoading
{
    class Formula
    {
        public double Area(double radius)
        {
            double result = (3.14) * radius * radius;
            return result;
        }
        public double Area(double length, double breadth)
        {
            double result = (length * breadth);
            return result;
        }
        public double Triangle(double length1, double length2, double length3)
        {
            double perimeter = (length1 + length2 + length3) / 2;
            double Triarea = ((perimeter - length1) * (perimeter - length2) * (perimeter - length3));
            double result = (perimeter * Triarea);
            double result1 = Math.Pow(result, 0.5);
            return result1;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Formula obj = new Formula();

            while (true)
            {
                Console.Write("Enter Your Choice: \n1.Rectangle.\n2.Triangle.\n3.Circle.\n4.Exit \n");
                int options = Convert.ToInt32(Console.ReadLine());

                switch (options)
                {
                    case 1:

                        Console.Write("Enter the Length of Rectangle: ");
                        double length = Convert.ToDouble(Console.ReadLine());

                        Console.Write("Enter the Breadth of Rectangle: ");
                        double breadth = Convert.ToDouble(Console.ReadLine());

                        double Rarea = obj.Area(length, breadth);
                        Console.WriteLine("Area of Rectangle: " + Rarea);

                        break;

                    case 2:

                        Console.Write("Enter the FIRST Length of Triangle: ");
                        double length1 = Convert.ToDouble(Console.ReadLine());

                        Console.Write("Enter the SECOND length of Triangle: ");
                        double length2 = Convert.ToDouble(Console.ReadLine());

                        Console.Write("Enter the THIRD Length of Triangle: ");
                        double length3 = Convert.ToDouble(Console.ReadLine());

                        double Tarea = obj.Triangle(length1, length2, length3);
                        Console.WriteLine("Area of Triangle " + Tarea);

                        break;

                    case 3:

                        Console.Write("Enter the Radius of Circle: ");
                        double radius = Convert.ToDouble(Console.ReadLine());

                        double Carea = obj.Area(radius);
                        Console.WriteLine("Area of Circle: " + Carea);

                        break;

                    case 4:

                        return;

                    default:

                        Console.WriteLine("Invalid Input");
                        
                        break;
                }
            }
        }
    }
}
