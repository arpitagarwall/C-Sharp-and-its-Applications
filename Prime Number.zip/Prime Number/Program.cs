﻿using System;

namespace Prime_Number
{
    class Program
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0060:Remove unused parameter", Justification = "<Pending>")]
        static void Main(string[] args)
        {

            Console.Write("Enter First number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            for (int num = num1; num <= num2; num++)
            {
                int count = 0;

                if (num > 1)
                {
                    for (int i = 2; i <= num; i++)
                    {
                        if (num != i && num % i == 0)
                        {
                            count = 1;
                            break;
                        }
                    }
                    if (count == 0)
                    {
                        Console.WriteLine(num);
                    }

                }
            }
        }
    }
}
