﻿using System;

namespace Toll_Booth
{
    class Program
    {
        static void Main(string[] args)
        {
            Booth obj = new Booth();

            while (true)
            {

                Console.WriteLine("Enter your choice: \n(A).Tag Cars. \n(B).Non-Tag Cars. \n(C).Non Paying Cars.");

                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.Escape:
                        obj.Money();
                        return;
                    case ConsoleKey.A:
                        obj.Tag();
                        break;
                    case ConsoleKey.B:
                        obj.NonTag();
                        break;
                    case ConsoleKey.C:
                        obj.NonPay();
                        break;
                    default:
                        Console.WriteLine("Wrong Choice, Try Again");
                        break;
                }

            }

        }
    }
    class Toll
    {
        public int Cars;
        public double Amount;

        public Toll()
        {
            Cars = 0;
            Amount = 0;
        }

        public virtual void Money()
        {
            Console.WriteLine(Cars);
            Console.WriteLine(Amount);
        }
    }
    class Booth : Toll
    {
        public void Tag()
        {
            Cars++;
            Amount += 50;

            Console.WriteLine(Cars);
            Console.WriteLine(Amount);
        }
        public void NonTag()
        {
            Cars++;
            Amount += 100;

            Console.WriteLine(Cars);
            Console.WriteLine(Amount);
        }
        public void NonPay()
        {
            Cars++;
            Amount += 0;

            Console.WriteLine(Cars);
            Console.WriteLine(Amount);
        }
    }
}