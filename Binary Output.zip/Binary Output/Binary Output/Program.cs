﻿using System;

namespace Binary_Output
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Enter a Number to convert it in Binary: ");
                int num = Convert.ToInt32(Console.ReadLine());

                string result = "";

                while (num > 1)
                {
                    int remainder = num % 2;
                    result = Convert.ToString(remainder) + result;
                    num /= 2;
                }

                result = Convert.ToString(num) + result;
                int Len = result.Length;
                if (Len == 1)
                {
                    result = "000" + result;
                    Console.WriteLine("Binary: {0}", result);
                    Console.ReadLine();
                }
                else if (Len == 2)
                {
                    result = "00" + result;
                    Console.WriteLine("Binary: {0}", result);
                    Console.ReadLine();
                }
                else if (Len == 3)
                {
                    result = "0" + result;
                    Console.WriteLine("Binary: {0}", result);
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Binary: {0}", result);
                    Console.ReadLine();
                }
            }
        }
    }
}