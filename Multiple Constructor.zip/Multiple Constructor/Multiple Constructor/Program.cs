﻿using System;
namespace Multiple_Construtor
{
    public class Constructor
    {
        public Constructor() : this(2, 2)
        {
            Console.WriteLine("2 Parameter");
        }
        public Constructor(int a, int b)
        {
            Console.WriteLine("Hello World!");
        }
        public Constructor(string ABC) : this()
        {
            Console.WriteLine("string parameter");
        }
    }
    public class Constructor2 : Constructor
    {
        public Constructor2()
        {
            Console.WriteLine("Inheritance Class");
        }
    }
    class Final
    {
        public static void Main()
        {
            Constructor2 obj = new Constructor2();
            Console.ReadLine();
        }
    }
}