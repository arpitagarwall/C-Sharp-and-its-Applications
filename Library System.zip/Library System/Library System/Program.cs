﻿using System;

namespace Library_System
{
    class Program
    {
        static void Main(string[] args)
        {
            BookStore obj = new BookStore();
            obj.Add();

            while (true)
            {
                Console.Write("\n1. Enter 1 to get books. \n2. Enter 2 to for Status.\n3. Exit\n");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {

                    case 1:
                        obj.BookInput();
                        break;

                    case 2:
                        obj.Overall();
                        break;
                    case 3:
                        return;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
        }
    }
    struct BookInfo
    {
        public string BookName;
        public int BookID;
        public string BookAuthor;
        public string BookLoanedTo;
        public int TotalBooks;
    }
    struct Borrow
    {
        public string BookName;
        public string BorrowerName;
        public string BookAuthor;
    }

    class BookStore
    {
        public int count = 0;
        public BookInfo[] Store = new BookInfo[5];
        public Borrow[] Lend = new Borrow[100];
        public void Add()
        {
            Store[0].BookName = "Data Structure and Algorithm";
            Store[0].BookID = 1;
            Store[0].BookAuthor = "Thomas H. Corman";
            Store[0].BookLoanedTo = string.Empty;
            Store[0].TotalBooks = 20;

            Store[1].BookName = "Maths By RS";
            Store[1].BookID = 2;
            Store[1].BookAuthor = "RS";
            Store[1].BookLoanedTo = string.Empty;
            Store[1].TotalBooks = 20;

            Store[2].BookName = "Let Us C";
            Store[2].BookID = 3;
            Store[2].BookAuthor = "Greg Perry";
            Store[2].BookLoanedTo = string.Empty;
            Store[2].TotalBooks = 20;

            Store[3].BookName = "Telecom Billing";
            Store[3].BookID = 4;
            Store[3].BookAuthor = "Greg Perry";
            Store[3].BookLoanedTo = string.Empty;
            Store[3].TotalBooks = 20;

            Store[4].BookName = "Csharp Programming";
            Store[4].BookID = 5;
            Store[4].BookAuthor = "Nuha Ali";
            Store[4].BookLoanedTo = string.Empty;
            Store[4].TotalBooks = 20;
        }
        private int Available(int id)
        {
            int TotalCount = Store[id].TotalBooks;
            int reserve = (TotalCount * 10) / 100;
            int avail = TotalCount - reserve;
            return avail;
        }
        public void BookInput()
        {

            Console.WriteLine("Press 1 for book Data Structure and Algorithm.");
            Console.WriteLine("Press 2 for book Maths By RS.");
            Console.WriteLine("Press 3 for book Let Us C.");
            Console.WriteLine("Press 4 for book Telecom Billing.");
            Console.WriteLine("Press 5 for book Csharp Programming.");
            Console.WriteLine("Enter your choice: ");
            int BookNo = Convert.ToInt32(Console.ReadLine());

            if (BookNo >= 1 && BookNo <= 5)
            {
                for (int ele = 0; ele < Store.Length; ele++)
                {
                    if (BookNo == Store[ele].BookID)
                    {
                        int LeftBook = Available(ele);
                        if (LeftBook > 0)
                        {
                            Console.WriteLine("Enter Your Alias: ");
                            string Alias = Console.ReadLine().ToUpper();
                            Store[ele].TotalBooks--;
                            Store[ele].BookLoanedTo = Alias;
                            Lend[count].BorrowerName = Alias;
                            Lend[count].BookAuthor = Store[ele].BookAuthor;
                            Lend[count].BookName = Store[ele].BookName;
                            count++;
                            Console.WriteLine(Store[ele].BookName + " has been Issued to " + Alias);
                        }
                        else
                        {
                            Console.WriteLine("Book is Unavailable");
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Input Invalid");
            }

        }
        public void Overall()
        {
            if (count > 0)
            {
                Console.WriteLine("Index" + "\tBorrower" + "\tAuthor" + "\tBookName");
                Console.WriteLine("_________________________________________________________");
                for (int i = 0; i < count; i++)
                {
                    Console.Write(i + "\t" + Lend[i].BorrowerName + "\t\t" + Lend[i].BookAuthor + "\t" + Lend[i].BookName);
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Data Unavailable");
            }
        }
    }
}
