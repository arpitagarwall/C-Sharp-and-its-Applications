﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_of_Rectangle_and_Triangle
{
    class Rectangle : Shape
    {
        public int Rectarea(int Length, int Breadth)
        {
            return Length * Breadth;
        }
    }
    class Triangle : Shape
    {
        public int Triarea(int Height, int Width)
        {
            return (Height * Width) / 2;
        }
    }
    class Shape
    {
        protected static void Main()
        {
            {
                Console.Write("Enter the Choice for which you have to find Area:\n");

                Console.Write("1-Rectangle.\n2-Triangle.\n3-Exit.\n");

                Console.Write("\nInput your choice : ");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.Write("Enter the Length of Rectangle: ");
                        int length = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the Breadth of Rectangle: ");
                        int breadth = Convert.ToInt32(Console.ReadLine());

                        Rectangle area1 = new Rectangle();
                        int Rarea = area1.Rectarea(length, breadth);

                        Console.WriteLine("The Area of Rectangle of Length  {0} and Breadth {1} is: {2}\n", length, breadth, Rarea);
                        Console.ReadLine();
                        break;

                    case 2:

                        Console.Write("Enter the Height of Triangle: ");
                        int height = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the Base of Triangle: ");
                        int width = Convert.ToInt32(Console.ReadLine());

                        Triangle area2 = new Triangle();
                        int Tarea = area2.Triarea(height, width);

                        Console.WriteLine("The Area of Triangle of Height  {0} and Base {1} is: {2}\n", height, width, Tarea);
                        Console.ReadLine();
                        break;

                    case 3:

                        break;

                    default:
                        Console.WriteLine("No match found");
                        break;
                }  
            }
        }
    }
}